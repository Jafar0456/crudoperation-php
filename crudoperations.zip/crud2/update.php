<?php include 'connection.php';
$id=$_GET['updateid'];
$sql="select * from contact where  id=$id";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
$name=$row['name'];
$email=$row['email'];
$phone=$row['phone'];
$password=$row['password'];
if($_SERVER['REQUEST_METHOD']=='POST'){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $password=$_POST['password'];
    $sql="update contact set id='$id',name='$name',email='$email',phone=$phone,password='$password'";
    $result=mysqli_query($conn,$sql);
    if($result){
        // echo "data updated  successfully";
        header('location:display.php');
    }else{
        die(mysqli_error($conn));
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud operator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Form</h1>
    <form class="form-control" method="POST" action="">
        Name:
        <input class="form-control" name="name" placeholder="Enter Name" required value="<?php echo $name;?>">
        Email:
        <input class="form-control" name="email" placeholder="Enter Email" required value="<?php echo $email;?>">
        Phone Number:
        <input class="form-control" name="phone" placeholder="Enter Phone Number" required value="<?php echo $phone;?>">
        Password:
        <input class="form-control" name="password" placeholder="Enter Password"required value="<?php echo $password;?>"><br>
        <button type="submit" class="btn btn-primary" value="submit" >Update</button>
        
    </form>
    </div>
</body>
</html>