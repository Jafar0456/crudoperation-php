<?php
$server="localhost";
$user="root";
$password="";
$dbname="crud";
$conn=new mysqli($server,$user,$password,$dbname);
if($conn){
   // echo "connection successfully";
}else{
    die(mysqli_error($conn));
}
?>